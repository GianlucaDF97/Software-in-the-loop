/* Copyright 2008-2014 The MathWorks, Inc. */

#ifndef _Arduino_Timer_h_
#define _Arduino_Timer_h_

unsigned long micros(void);

#endif
